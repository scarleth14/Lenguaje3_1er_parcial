﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    public class Solicitudes
    {
        public string Solicitud { get; set; }

        public Solicitudes() { }

        public Solicitudes(string solicitud)
        {
            Solicitud = solicitud;
        }
    }
}
