﻿
namespace ScarlethBaquedano
{
    partial class Multiplos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbx_numeros = new System.Windows.Forms.ListBox();
            this.lbx_MultiplosDe3 = new System.Windows.Forms.ListBox();
            this.lbx_MultiplosDe5 = new System.Windows.Forms.ListBox();
            this.lbx_MultiplosDe3y5 = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_apellido = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.pbx_siguiente = new System.Windows.Forms.PictureBox();
            this.btn_limpiar = new System.Windows.Forms.Button();
            this.btn_mostrar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_siguiente)).BeginInit();
            this.SuspendLayout();
            // 
            // lbx_numeros
            // 
            this.lbx_numeros.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbx_numeros.FormattingEnabled = true;
            this.lbx_numeros.ItemHeight = 21;
            this.lbx_numeros.Location = new System.Drawing.Point(19, 180);
            this.lbx_numeros.Name = "lbx_numeros";
            this.lbx_numeros.Size = new System.Drawing.Size(179, 508);
            this.lbx_numeros.TabIndex = 0;
            // 
            // lbx_MultiplosDe3
            // 
            this.lbx_MultiplosDe3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbx_MultiplosDe3.FormattingEnabled = true;
            this.lbx_MultiplosDe3.ItemHeight = 21;
            this.lbx_MultiplosDe3.Location = new System.Drawing.Point(230, 180);
            this.lbx_MultiplosDe3.Name = "lbx_MultiplosDe3";
            this.lbx_MultiplosDe3.Size = new System.Drawing.Size(179, 508);
            this.lbx_MultiplosDe3.TabIndex = 1;
            // 
            // lbx_MultiplosDe5
            // 
            this.lbx_MultiplosDe5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbx_MultiplosDe5.FormattingEnabled = true;
            this.lbx_MultiplosDe5.ItemHeight = 21;
            this.lbx_MultiplosDe5.Location = new System.Drawing.Point(449, 180);
            this.lbx_MultiplosDe5.Name = "lbx_MultiplosDe5";
            this.lbx_MultiplosDe5.Size = new System.Drawing.Size(179, 508);
            this.lbx_MultiplosDe5.TabIndex = 2;
            // 
            // lbx_MultiplosDe3y5
            // 
            this.lbx_MultiplosDe3y5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbx_MultiplosDe3y5.FormattingEnabled = true;
            this.lbx_MultiplosDe3y5.ItemHeight = 21;
            this.lbx_MultiplosDe3y5.Location = new System.Drawing.Point(664, 180);
            this.lbx_MultiplosDe3y5.Name = "lbx_MultiplosDe3y5";
            this.lbx_MultiplosDe3y5.Size = new System.Drawing.Size(221, 508);
            this.lbx_MultiplosDe3y5.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Milasian Circa Bold PERSONAL", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(441, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(171, 43);
            this.label5.TabIndex = 13;
            this.label5.Text = "¡Bienvenido!";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(180, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 21);
            this.label1.TabIndex = 14;
            this.label1.Text = "Nombre";
            // 
            // txt_nombre
            // 
            this.txt_nombre.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nombre.Location = new System.Drawing.Point(287, 91);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(159, 27);
            this.txt_nombre.TabIndex = 16;
            this.txt_nombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_nombre_KeyPress);
            this.txt_nombre.Leave += new System.EventHandler(this.txt_nombre_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(496, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 21);
            this.label2.TabIndex = 17;
            this.label2.Text = "Apellido";
            // 
            // txt_apellido
            // 
            this.txt_apellido.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_apellido.Location = new System.Drawing.Point(590, 88);
            this.txt_apellido.Name = "txt_apellido";
            this.txt_apellido.Size = new System.Drawing.Size(159, 27);
            this.txt_apellido.TabIndex = 18;
            this.txt_apellido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_apellido_KeyPress);
            this.txt_apellido.Leave += new System.EventHandler(this.txt_apellido_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 19);
            this.label3.TabIndex = 19;
            this.label3.Text = "Números 1 - 100";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(254, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 19);
            this.label4.TabIndex = 20;
            this.label4.Text = "Múltiplos de 3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(478, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 19);
            this.label6.TabIndex = 21;
            this.label6.Text = "Múltiplos de 5";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(695, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(140, 19);
            this.label7.TabIndex = 22;
            this.label7.Text = "Múltiplos de 3 y 5";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // pbx_siguiente
            // 
            this.pbx_siguiente.BackgroundImage = global::ScarlethBaquedano.Properties.Resources.icons8_flecha_adelante_100;
            this.pbx_siguiente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbx_siguiente.Location = new System.Drawing.Point(929, 568);
            this.pbx_siguiente.Name = "pbx_siguiente";
            this.pbx_siguiente.Size = new System.Drawing.Size(117, 120);
            this.pbx_siguiente.TabIndex = 24;
            this.pbx_siguiente.TabStop = false;
            this.pbx_siguiente.Click += new System.EventHandler(this.pbx_siguiente_Click);
            // 
            // btn_limpiar
            // 
            this.btn_limpiar.BackColor = System.Drawing.Color.MediumOrchid;
            this.btn_limpiar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_limpiar.ForeColor = System.Drawing.Color.Black;
            this.btn_limpiar.Image = global::ScarlethBaquedano.Properties.Resources.icons8_borrar_96;
            this.btn_limpiar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_limpiar.Location = new System.Drawing.Point(895, 335);
            this.btn_limpiar.Name = "btn_limpiar";
            this.btn_limpiar.Size = new System.Drawing.Size(168, 98);
            this.btn_limpiar.TabIndex = 23;
            this.btn_limpiar.Text = "Limpiar";
            this.btn_limpiar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_limpiar.UseVisualStyleBackColor = false;
            this.btn_limpiar.Click += new System.EventHandler(this.btn_limpiar_Click);
            // 
            // btn_mostrar
            // 
            this.btn_mostrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(119)))), ((int)(((byte)(169)))), ((int)(((byte)(251)))));
            this.btn_mostrar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mostrar.ForeColor = System.Drawing.Color.Black;
            this.btn_mostrar.Image = global::ScarlethBaquedano.Properties.Resources.icons8_visible_96;
            this.btn_mostrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_mostrar.Location = new System.Drawing.Point(895, 233);
            this.btn_mostrar.Name = "btn_mostrar";
            this.btn_mostrar.Size = new System.Drawing.Size(168, 84);
            this.btn_mostrar.TabIndex = 4;
            this.btn_mostrar.Text = "Mostrar";
            this.btn_mostrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_mostrar.UseVisualStyleBackColor = false;
            this.btn_mostrar.Click += new System.EventHandler(this.btn_mostrar_Click);
            // 
            // Multiplos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1075, 723);
            this.Controls.Add(this.pbx_siguiente);
            this.Controls.Add(this.btn_limpiar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_apellido);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_mostrar);
            this.Controls.Add(this.lbx_MultiplosDe3y5);
            this.Controls.Add(this.lbx_MultiplosDe5);
            this.Controls.Add(this.lbx_MultiplosDe3);
            this.Controls.Add(this.lbx_numeros);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "Multiplos";
            this.Text = "Multiplos";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_siguiente)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbx_numeros;
        private System.Windows.Forms.ListBox lbx_MultiplosDe3;
        private System.Windows.Forms.ListBox lbx_MultiplosDe5;
        private System.Windows.Forms.ListBox lbx_MultiplosDe3y5;
        private System.Windows.Forms.Button btn_mostrar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_apellido;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button btn_limpiar;
        private System.Windows.Forms.PictureBox pbx_siguiente;
    }
}